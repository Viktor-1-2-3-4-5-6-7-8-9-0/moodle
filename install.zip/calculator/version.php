<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_calculator';
$plugin->version = 2025111400;
$plugin->requires = 2022112800;
$plugin->maturity = MATURITY_STABLE;